import UIKit
import SwiftUI

var ingredients = """
tomato 1 piece
basil 1 pack
balsamic sauce
pasta 1 package
100gr of Carrot
"""
var steps = """
Cook hard. Cook with pleasure
Cook with smile.

Cook healthy
"""

// What's the goal?!
//
// The goal is to get the ingredients array
// Extract each element and his corresponding quantity.

// Save an array of steps, possibly, clean it out of numbers: 1. 2. 3. ,... ....
// Split step elements in the array into array of micro-steps. Each sentence inside a step - is microstep

// If the line is empty, we should remove corresponding empty string from array of steps. (I.e. check *steps* array for empty strings)

/// Receiving an array of ingredients
ingredients.components(separatedBy: "\n")
/// Receiving an array of steps
steps.components(separatedBy: "\n\n")


