import UIKit


let now = Date()
print(now.timeIntervalSince(Date() - 60))

// save the 'date' when Fuely starts to speak
// save the 'date' when Fuely finishes to speak
// calculate the difference, save the difference

let regexPattern = #"(\d{1,2}\s)?\d{1,}(\.\d{1,2})?([\/]\d{1,2})?(\s{0,5}?)(?i)(g|gr|gram|kg|tsp|kilogram|cups|can|litre|liter|L|milliliter|ml|mills|ounce|oz|pound|lb|tablespoon|tbsp|teaspoon|bunch|packet|pinch)+?(s\b|es\b|\b)(?-i)"#
func decompose(_ inputText: String) -> (quantity: String, productName: String) {
    
    //let pattern = "[0-9]{1,}gr"
    var quantity = ""
    var productName = inputText
    
    let pattern = regexPattern
        
        let regexOptions: NSRegularExpression.Options = [.caseInsensitive]
        let matchingOptions: NSRegularExpression.MatchingOptions = [.reportCompletion]
        let range = NSRange(location: 0, length: inputText.utf16.count)
        
        
        let regex = try? NSRegularExpression(pattern: pattern, options: regexOptions)
         if let matchIndex = regex?.firstMatch(in: inputText, options: matchingOptions, range: range) {
            
            let startIndex = inputText.index(inputText.startIndex, offsetBy: matchIndex.range.lowerBound)
            let endIndex = inputText.index(inputText.startIndex, offsetBy: matchIndex.range.upperBound)
            
            quantity = String(inputText[startIndex..<endIndex])
            quantity = quantity.trimmingCharacters(in: .whitespaces)
            
            productName.removeSubrange(startIndex..<endIndex)
            
            
        } else {
            print("\n No match for --- \(inputText) ---. \n")
        }
        
        //pattern to remove things like 'of'
        let patternToRemoveConnectors = #"^\s{0,}?(of)"#
        let regexToRemoveConnectors = try! NSRegularExpression(pattern: patternToRemoveConnectors, options: regexOptions)
        if let connectorsRange = regexToRemoveConnectors.firstMatch(in: productName, options: matchingOptions, range: NSRange(location: 0, length: productName.utf16.count)) {
            
            let startIndex = productName.index(productName.startIndex, offsetBy: connectorsRange.range.lowerBound)
            let endIndex = productName.index(productName.startIndex, offsetBy: connectorsRange.range.upperBound)
            
            productName.removeSubrange(startIndex..<endIndex)
            
        } else {
            // No match for removing connectors
        }
    
    
    // final touch on productName string
    productName = productName.trimmingCharacters(in: .whitespaces)
    
    return (quantity, productName)
}

var testStr1 = "1 tsp of magic"
var testStr2 = "5 1/4 oz shredded mozarella"

decompose(testStr1)


import Foundation
import NaturalLanguage

// TODO: check that the regex pattern eventually of format #" "#


/// Returns language of input String. (optional)
func checkLanguage(of inputText: String) -> String? { // <- TODO I think of renaming it into - `returnLanguage(of:...)`
    /// `NSLinguisticTagger` checks the dominant language and outputs format like this - "en", "fr", etc. It's optional value.
    return NSLinguisticTagger.dominantLanguage(for: inputText)
}

/// Returns matching regex pattern for the text input.
/// Takes an `inputText`, checks its language, matches detected language with dictionary keys and returns proper regex pattern.
/// If there's no such a language in dictionary, function returns nil.
func regexPattern(for inputText: String) -> String? {
    
    if let language = checkLanguage(of: inputText) {
        return regexPatterns[language] ?? nil
    } else {
        print("language wasn't identified")
        return nil
    }
}

/// Dictionary of regex patterns, keyed by the language
/// - note: regex patterns should be encapsulated into following quote marks:  #" "#
var regexPatterns: [RegexLanguage.RawValue: String] = [
    RegexLanguage.en.self.rawValue: #"(\d{1,2}\s)?\d{1,}(\.\d{1,2})?([\/]\d{1,2})?(\s{0,5}?)(?i)(g|gr|gram|kg|tsp|kilogram|cups|can|litre|liter|L|milliliter|ml|mills|ounce|oz|pound|lb|tablespoon|tbsp|teaspoon|bunch|packet|pinch)+?(s\b|es\b|\b)(?-i)"#,
    RegexLanguage.he.self.rawValue: #"זו דוגמה של אנליזת הטקסט בעברית"#,
    RegexLanguage.ru.self.rawValue: #"это русский образец анализа текста"#
]

///Supported languages for regex patterns
enum RegexLanguage: String {
    case en, he, ru, notAvailable
    
    // look, what's possible to do - change cases to more readable, like:
    // English, Hebrew, Russian
    // and then in description math them with unicode notation system
    var description : String {
        switch self {
        // Use Internationalization, as appropriate.
        case .en: return "en"
        case .he: return "he"
        case .ru: return "ru"
        case .notAvailable: return "not available"
        }
    }
}


regexPattern(for: testStr1)
decompose(testStr2)
